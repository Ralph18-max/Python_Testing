import pytest
from server import app, clubs, competitions
from datetime import datetime, timedelta
from html import unescape


# -----------------------------
# Test 1 : Page index accessible
# -----------------------------
def test_index(client):
    response = client.get('/')
    assert response.status_code == 200
    assert b"Welcome" in response.data or b"Clubs" in response.data

# -------------------------------------------------
# Test 2 : Show summary avec email valide / invalide
# -------------------------------------------------
def test_show_summary_valid_email(client):
    email = clubs[0]['email']
    response = client.post('/showSummary', data={'email': email})
    assert response.status_code == 200
    assert bytes(email, 'utf-8') in response.data

def test_show_summary_invalid_email(client):
    response = client.post('/showSummary', data={'email': 'john@simplylift.ci'}, follow_redirects=True)
    assert b"Adresse email invalide. Veuillez entrer un email valide." in response.data

# ------------------------------------------
# Test 3 : Réserver une compétition passée
# ------------------------------------------
def test_book_past_competition(client):
    past_comp = {
        "name": "Past Competition",
        "date": (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S"),
        "numberOfPlaces": 10
    }
    app.competitions.append(past_comp)
    response = client.get(f"/book/{past_comp['name']}/{clubs[0]['name']}", follow_redirects=True)
    assert "Vous ne pouvez pas reserver pour une compétition passee.".encode('utf-8') in response.data

# ------------------------------------------
# Test 4 : Réserver plus de places que disponible
# ------------------------------------------
def test_purchase_more_than_available(client):
    comp = {
        "name": "Limited Competition",
        "date": (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S"),
        "numberOfPlaces": 5
    }
    app.competitions.append(comp)
    response = client.post('/purchasePlaces', data={
        'competition': comp['name'],
        'club': clubs[0]['name'],
        'places': 10
    }, follow_redirects=True)
    assert bytes(f"Seulement {comp['numberOfPlaces']} places disponibles.", 'utf-8') in response.data

# ------------------------------------------
# Test 5 : Réserver plus de 12 places
# ------------------------------------------
def test_purchase_more_than_12(client):
    comp = {
        "name": "Big Competition",
        "date": (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S"),
        "numberOfPlaces": 20
    }
    app.competitions.append(comp)
    response = client.post('/purchasePlaces', data={
        'competition': comp['name'],
        'club': clubs[0]['name'],
        'places': 13
    }, follow_redirects=True)
    assert b"Vous ne pouvez pas reserver plus de 12 places." in response.data

# ------------------------------------------
# Test 6 : Réserver avec plus de points que le club
# ------------------------------------------
def test_purchase_more_than_points(client):
    comp = {
        "name": "Points Competition",
        "date": (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S"),
        "numberOfPlaces": 10
    }
    app.competitions.append(comp)
    club = clubs[0]
    club['points'] = 2
    response = client.post('/purchasePlaces', data={
        'competition': comp['name'],
        'club': club['name'],
        'places': 5
    }, follow_redirects=True)
    decoded_html = unescape(response.data.decode('utf-8'))
    assert response.status_code == 200
    assert bytes(f"Vous n'avez que {club['points']} points disponibles.", 'utf-8') in decoded_html.encode('utf-8')

# ------------------------------------------
# Test 7 : Réservation réussie
# ------------------------------------------
def test_successful_purchase(client):
    comp = {
        "name": "Success Competition",
        "date": (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S"),
        "numberOfPlaces": 10
    }
    app.competitions.append(comp)
    club = clubs[0]
    club['points'] = 10
    response = client.post('/purchasePlaces', data={
        'competition': comp['name'],
        'club': club['name'],
        'places': 5
    }, follow_redirects=True)
    assert "Réservation réussie !".encode('utf-8') in response.data
    # Vérifier que les points et places ont été mis à jour
    assert club['points'] == 5
    assert comp['numberOfPlaces'] == 5
